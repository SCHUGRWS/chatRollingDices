package br.org.catolicasc.chatRollingDices.servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class Cliente extends Thread{

	//private String clientName = null;
	private DataInputStream inputStream = null;
	private DataOutputStream outputStream = null;
	private Socket clientSocket = null;
	private final Cliente[] threads;
	private int maxClientsCount;

	public Cliente(Socket clientSocket, Cliente[] threads) {
		this.clientSocket = clientSocket;
		this.threads = threads;
		maxClientsCount = threads.length;
	}

	public void run() {
		int maxClientsCount = this.maxClientsCount;
		Cliente[] threads = this.threads;

		try {
			/*
			 * Create input and output streams for this client.
			 */
			inputStream = new DataInputStream(clientSocket.getInputStream());
			outputStream = new DataOutputStream(clientSocket.getOutputStream());
			String name;
			while (true) {
				outputStream.writeUTF("Envie seu nome");
				name = inputStream.readUTF().trim();
				if (name.length() > 0) {
					break;
				}else{
					outputStream.writeUTF("Envie seu nome");
				}
			}

			outputStream.writeUTF("Bem vindo: " + name
					+ "\nClique em sair para encerrar a sess�o!");
			synchronized (this) {
				for (int i = 0; i < maxClientsCount; i++) {
					if (threads[i] != null && threads[i] == this) {
						break;
					}
				}
				for (int i = 0; i < maxClientsCount; i++) {
					if (threads[i] != null && threads[i] != this) {
						threads[i].outputStream.writeUTF("*** Um novo usuario entrou: " + name);
					}
				}
			}

			while (true) {
				String mensagem = inputStream.readUTF();
				if (mensagem.startsWith("/quit")) {
					break;
				}

				synchronized (this) {
					for (int i = 0; i < maxClientsCount; i++) {
						if (threads[i] != null) {
							threads[i].outputStream.writeUTF("<" + name + "> " + mensagem);
						}
					}
				}
			}
			synchronized (this) {
				for (int i = 0; i < maxClientsCount; i++) {
					if (threads[i] != null && threads[i] != this) {
						threads[i].outputStream.writeUTF("O usu�rio " + name + " deixou o servidor!");
					}
				}
			}
			outputStream.writeUTF("*** Saiu ***");

			synchronized (this) {
				for (int i = 0; i < maxClientsCount; i++) {
					if (threads[i] == this) {
						threads[i] = null;
					}
				}
			}
			
			inputStream.close();
			outputStream.close();
			clientSocket.close();
		} catch (IOException e) {
		}
	}
}