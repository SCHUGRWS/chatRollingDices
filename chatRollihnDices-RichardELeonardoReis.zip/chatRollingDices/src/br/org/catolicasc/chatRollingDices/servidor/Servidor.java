package br.org.catolicasc.chatRollingDices.servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
	
	private static ServerSocket serverSocket = null;
	  private static Socket clientSocket = null;

	  private static final int maxClientsCount = 9999;
	  private static final Cliente[] threads = new Cliente[maxClientsCount];

	  public static void main(String args[]) {

	    int portNumber = 6500;

	    try {
	      serverSocket = new ServerSocket(portNumber);
	    } catch (IOException e) {
	      System.out.println(e);
	    }

	    while (true) {
	      try {
	        clientSocket = serverSocket.accept();
	        int i = 0;
	        for (i = 0; i < maxClientsCount; i++) {
	          if (threads[i] == null) {
	            (threads[i] = new Cliente(clientSocket, threads)).start();
	            break;
	          }
	        }
	        if (i == maxClientsCount) {
	          DataOutputStream outputStream = new DataOutputStream(clientSocket.getOutputStream());
	          outputStream.writeUTF("Server too busy. Try later.");
	          outputStream.close();
	          clientSocket.close();
	        }
	      } catch (IOException e) {
	        System.out.println(e);
	      }
	    }
	  }
	}
