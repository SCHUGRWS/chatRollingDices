package br.org.catolicasc.chatRollingDices.telaChat;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.UnknownHostException;

import javax.swing.SwingUtilities;
import javax.swing.event.SwingPropertyChangeSupport;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;

public class Chat {

	protected Shell shell= new Shell();
	private Text mensagem;
	public Text chat = new Text(shell, SWT.MULTI | SWT.BORDER | SWT.WRAP | SWT.V_SCROLL);
	private ChatThread chatThread;

	// The client socket
	private static Socket clientSocket = null;
	// The output stream
	private static DataOutputStream outputStream = null;
	// The input stream
	private static DataInputStream inputStream = null;

	private static BufferedReader inputLine = null;
	private static boolean closed = false;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Chat window = new Chat();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @throws IOException 
	 * @throws UnknownHostException 
	 */
	public void open() throws UnknownHostException, IOException {
		chat.setForeground(SWTResourceManager.getColor(SWT.COLOR_TRANSPARENT));
		chat.setBackground(SWTResourceManager.getColor(SWT.COLOR_TRANSPARENT));
		try
		{
			// The default port.
			int portNumber = 6500;
			// The default host.
			String host = "localhost";

			/*
			 * Open a socket on a given host and port. Open input and output streams.
			 */
			try {
				clientSocket = new Socket(host, portNumber);
				inputLine = new BufferedReader(new InputStreamReader(System.in));
				outputStream = new DataOutputStream(clientSocket.getOutputStream());
				inputStream = new DataInputStream(clientSocket.getInputStream());
			} catch (Exception e) {
				System.err.println("Erro:" + e.getMessage());
			}

			/*
			 * If everything has been initialized then we want to write some data to the
			 * socket we have opened a connection to on the port portNumber.
			 */
			if (clientSocket != null && outputStream != null && inputStream != null) {
				try {
					

					chatThread = new ChatThread(inputStream);
					/*Create a thread to read from the server.*/
				      chatThread.addPropertyChangeListener(new PropertyChangeListener() {

				          @Override
				          public void propertyChange(PropertyChangeEvent pcEvt) {
				        	  chat.append(pcEvt.getNewValue()+"\n");
				          }

				       });
				      
				       //new Thread(chatThread).start();
					
				    Display display = Display.getDefault();
					createContents(display);
					shell.open();
					shell.layout();
					
				     SwingUtilities.invokeLater(chatThread);

					
					while (!shell.isDisposed()) {
						if (!display.readAndDispatch()) {
							display.sleep();
						}
					}
					outputStream.close();
					inputStream.close();
					clientSocket.close();
				} catch (Exception e) {
					//System.err.println("IOException:  " + e);
				}
			}
		}catch (Exception e) {
			//e.printStackTrace();
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents(Display display) {
		shell = new Shell(display);
		shell.setSize(819, 549);
		shell.setText("Char RPG Rolling Dices");
		shell.addListener(SWT.Close, new Listener() {
			@Override
		      public void handleEvent(Event event) {
				String texto = "/quit";
				try {
					outputStream.writeUTF(texto);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
				}
		      }

		    });
		
		mensagem = new Text(shell, SWT.BORDER);
		mensagem.setBounds(10, 341, 636, 140);
		
		chat=new Text(shell, SWT.MULTI | SWT.BORDER | SWT.WRAP | SWT.V_SCROLL);
		chat.setLayoutData(new GridData(GridData.FILL_BOTH));
		chat.setBackground(SWTResourceManager.getColor(SWT.COLOR_TRANSPARENT));
		chat.setEditable(false);
		chat.setBounds(10, 10, 781, 325);
		
		Button btnEnviar = new Button(shell, SWT.NONE);
		btnEnviar.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {
					String texto = mensagem.getText();
					outputStream.writeUTF(texto);
				} catch (Exception e2) {
					MessageDialog.openError(shell, "Error", e2.getMessage());
					return;
				}
			}
		});
		btnEnviar.setBounds(660, 350, 131, 30);
		btnEnviar.setText("Enviar");
		
		Button btnRolarDados = new Button(shell, SWT.NONE);
		btnRolarDados.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {

					String texto = "";
					String rolagem = Double.toString((Math.random()*19)+1);
					rolagem=rolagem.substring(0,2);
					texto="Rolando D20: "+rolagem.substring(0,2);
					outputStream.writeUTF(texto);
				} catch (Exception e2) {
					MessageDialog.openError(shell, "Error", e2.getMessage());
					return;
				}
			}
		});
		btnRolarDados.setBounds(660, 402, 131, 30);
		btnRolarDados.setText("Rolar Dados");
		
		Button btnSair = new Button(shell, SWT.NONE);
		btnSair.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {
					String texto = "/quit";
					outputStream.writeUTF(texto);
					shell.close();
				} catch (Exception e2) {
					MessageDialog.openError(shell, "Error", e2.getMessage());
					return;
				}
			}
		});
		btnSair.setBounds(660, 454, 131, 30);
		btnSair.setText("Sair");

	}

	public Text getMensagem() {
		return mensagem;
	}

	public void setMensagem(Text mensagem) {
		this.mensagem = mensagem;
	}
}

class ChatThread implements Runnable {

	private String textoServer;
	private SwingPropertyChangeSupport swingSupport = new SwingPropertyChangeSupport(this);
	private DataInputStream inputStream = null;

	public void run() {
		/*
		 * Keep on reading from the socket till we receive "Bye" from the
		 * server. Once we received that then we want to break.
		 */
		String responseLine;
		try {
			while ((responseLine = inputStream.readUTF()) != null) {
				
				String oldText=this.getTextoServer()+"1";
				String newText=responseLine;
				this.setTextoServer(responseLine);
				//System.out.println(responseLine);
				Display.getDefault().asyncExec(new Runnable() {
		               public void run() {
		            	   swingSupport.firePropertyChange("textoServer", oldText, newText);
		               }
		            });
				
				if (responseLine.indexOf("*** Saiu ***") != -1)
					break;
			}
		} catch (Exception e) {
			System.err.println("IOException:  " + e.getMessage());
		}
	}

	public void addPropertyChangeListener(PropertyChangeListener listener) {
	   swingSupport.addPropertyChangeListener(listener);
	}
	
	public void removePropertyChangeListener(PropertyChangeListener listener) {
	   swingSupport.removePropertyChangeListener(listener);
	}

	
	public String getTextoServer() {
		return textoServer;
	}

	public void setTextoServer(String textoServer) {
		this.textoServer = textoServer;
	}

	public ChatThread(DataInputStream inputStream) {
		super();
		this.inputStream = inputStream;
	}
	
	
	

}
